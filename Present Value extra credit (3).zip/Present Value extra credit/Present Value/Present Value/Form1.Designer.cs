﻿namespace Present_Value
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.futureValueDescriptionLabel = new System.Windows.Forms.Label();
            this.numberOfYearsDescriptionLabel = new System.Windows.Forms.Label();
            this.interestRateDescriptionLabel = new System.Windows.Forms.Label();
            this.presentValueDescriptionLabel = new System.Windows.Forms.Label();
            this.futureValueTextBox = new System.Windows.Forms.TextBox();
            this.yearsTextBox = new System.Windows.Forms.TextBox();
            this.annualInterestRateTextBox = new System.Windows.Forms.TextBox();
            this.presentValueLabel = new System.Windows.Forms.Label();
            this.calcInitialDepositButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // futureValueDescriptionLabel
            // 
            this.futureValueDescriptionLabel.AutoSize = true;
            this.futureValueDescriptionLabel.Location = new System.Drawing.Point(12, 39);
            this.futureValueDescriptionLabel.Name = "futureValueDescriptionLabel";
            this.futureValueDescriptionLabel.Size = new System.Drawing.Size(106, 13);
            this.futureValueDescriptionLabel.TabIndex = 0;
            this.futureValueDescriptionLabel.Text = "Future value desired:";
            // 
            // numberOfYearsDescriptionLabel
            // 
            this.numberOfYearsDescriptionLabel.AutoSize = true;
            this.numberOfYearsDescriptionLabel.Location = new System.Drawing.Point(245, 39);
            this.numberOfYearsDescriptionLabel.Name = "numberOfYearsDescriptionLabel";
            this.numberOfYearsDescriptionLabel.Size = new System.Drawing.Size(114, 13);
            this.numberOfYearsDescriptionLabel.TabIndex = 1;
            this.numberOfYearsDescriptionLabel.Text = "Years to grow savings:";
            // 
            // interestRateDescriptionLabel
            // 
            this.interestRateDescriptionLabel.AutoSize = true;
            this.interestRateDescriptionLabel.Location = new System.Drawing.Point(500, 39);
            this.interestRateDescriptionLabel.Name = "interestRateDescriptionLabel";
            this.interestRateDescriptionLabel.Size = new System.Drawing.Size(101, 13);
            this.interestRateDescriptionLabel.TabIndex = 2;
            this.interestRateDescriptionLabel.Text = "Annual interest rate:";
            // 
            // presentValueDescriptionLabel
            // 
            this.presentValueDescriptionLabel.AutoSize = true;
            this.presentValueDescriptionLabel.Location = new System.Drawing.Point(245, 84);
            this.presentValueDescriptionLabel.Name = "presentValueDescriptionLabel";
            this.presentValueDescriptionLabel.Size = new System.Drawing.Size(239, 13);
            this.presentValueDescriptionLabel.TabIndex = 3;
            this.presentValueDescriptionLabel.Text = "You will need to make the following initial deposit:";
            // 
            // futureValueTextBox
            // 
            this.futureValueTextBox.Location = new System.Drawing.Point(124, 32);
            this.futureValueTextBox.Name = "futureValueTextBox";
            this.futureValueTextBox.Size = new System.Drawing.Size(80, 20);
            this.futureValueTextBox.TabIndex = 4;
            // 
            // yearsTextBox
            // 
            this.yearsTextBox.Location = new System.Drawing.Point(365, 32);
            this.yearsTextBox.Name = "yearsTextBox";
            this.yearsTextBox.Size = new System.Drawing.Size(80, 20);
            this.yearsTextBox.TabIndex = 5;
            // 
            // annualInterestRateTextBox
            // 
            this.annualInterestRateTextBox.Location = new System.Drawing.Point(607, 32);
            this.annualInterestRateTextBox.Name = "annualInterestRateTextBox";
            this.annualInterestRateTextBox.Size = new System.Drawing.Size(80, 20);
            this.annualInterestRateTextBox.TabIndex = 6;
            // 
            // presentValueLabel
            // 
            this.presentValueLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.presentValueLabel.Location = new System.Drawing.Point(309, 111);
            this.presentValueLabel.Name = "presentValueLabel";
            this.presentValueLabel.Size = new System.Drawing.Size(117, 19);
            this.presentValueLabel.TabIndex = 7;
            this.presentValueLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // calcInitialDepositButton
            // 
            this.calcInitialDepositButton.Location = new System.Drawing.Point(228, 151);
            this.calcInitialDepositButton.Name = "calcInitialDepositButton";
            this.calcInitialDepositButton.Size = new System.Drawing.Size(89, 37);
            this.calcInitialDepositButton.TabIndex = 8;
            this.calcInitialDepositButton.Text = "Calculate Initial Deposit";
            this.calcInitialDepositButton.UseVisualStyleBackColor = true;
            this.calcInitialDepositButton.Click += new System.EventHandler(this.calcInitialDepositButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(416, 151);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(89, 37);
            this.exitButton.TabIndex = 9;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(705, 228);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.calcInitialDepositButton);
            this.Controls.Add(this.presentValueLabel);
            this.Controls.Add(this.annualInterestRateTextBox);
            this.Controls.Add(this.yearsTextBox);
            this.Controls.Add(this.futureValueTextBox);
            this.Controls.Add(this.presentValueDescriptionLabel);
            this.Controls.Add(this.interestRateDescriptionLabel);
            this.Controls.Add(this.numberOfYearsDescriptionLabel);
            this.Controls.Add(this.futureValueDescriptionLabel);
            this.Name = "Form1";
            this.Text = "Present Value Calculator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label futureValueDescriptionLabel;
        private System.Windows.Forms.Label numberOfYearsDescriptionLabel;
        private System.Windows.Forms.Label interestRateDescriptionLabel;
        private System.Windows.Forms.Label presentValueDescriptionLabel;
        private System.Windows.Forms.TextBox futureValueTextBox;
        private System.Windows.Forms.TextBox yearsTextBox;
        private System.Windows.Forms.TextBox annualInterestRateTextBox;
        private System.Windows.Forms.Label presentValueLabel;
        private System.Windows.Forms.Button calcInitialDepositButton;
        private System.Windows.Forms.Button exitButton;
    }
}

