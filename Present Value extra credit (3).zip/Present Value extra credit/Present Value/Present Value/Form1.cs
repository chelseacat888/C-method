﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Present_Value
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //Add your PresentValue method here

        public double PresentValue( double F, double r, double n)
        {

            
            double P = F / Math.Pow((1 + r),n); // calculate equation
            return P; // return value

        }
        







        private void calcInitialDepositButton_Click(object sender, EventArgs e)
        {
            //I did the extra credit

            //Variables
            double presentValue = 0, futureValue = 0, years = 0, annualInterestRate = 0; // initialized the values so the if/else statements can work
            

            //Check all the inputs
            if (double.TryParse(futureValueTextBox.Text, out futureValue) &&
                double.TryParse(yearsTextBox.Text, out years) &&
                double.TryParse(annualInterestRateTextBox.Text, out annualInterestRate))
            {

               

                //All good, so calculate
                presentValue = PresentValue(futureValue, annualInterestRate, years);//Add code here to call the PresentValue method
                // used different parameters and arguments

                //Display result
                presentValueLabel.Text = presentValue.ToString("c");

               
            }
           
            else
            {
                //Must have been an input error
                MessageBox.Show("Invalid Data Entered!");
            }

            if (futureValue < 1000) // if years are less than 1000
            {
                MessageBox.Show("Invalid Future Value ");
                futureValueTextBox.Text = "";
                yearsTextBox.Text = "";
                annualInterestRateTextBox.Text = "";
                presentValueLabel.Text = "";
            }
            else
            {

                //All good, so calculate
                presentValue = PresentValue(futureValue, annualInterestRate, years);//Add code here to call the PresentValue method
                // used different parameters and arguments


            }

            if (years <= 0 || years > 30) // years have to be more than 0 and no more than 30
            {
                MessageBox.Show("Invalid Years ");
                futureValueTextBox.Text = "";
                yearsTextBox.Text = "";
                annualInterestRateTextBox.Text = "";
                presentValueLabel.Text = "";
            }
            else
            {

                //All good, so calculate
                presentValue = PresentValue(futureValue, annualInterestRate, years);//Add code here to call the PresentValue method
                // used different parameters and arguments


            }

            if (annualInterestRate <= 0.01 || annualInterestRate >= 0.24) // interest rate has to be between 0.01 and 0.24
            {
                MessageBox.Show("Invalid Interest Rate ");
                futureValueTextBox.Text = "";
                yearsTextBox.Text = "";
                annualInterestRateTextBox.Text = "";
                presentValueLabel.Text = "";
            }
            else
            {

                //All good, so calculate
                presentValue = PresentValue(futureValue, annualInterestRate, years);//Add code here to call the PresentValue method
                // used different parameters and arguments


            }

    }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Close the form
            this.Close();
        }
    }
}
